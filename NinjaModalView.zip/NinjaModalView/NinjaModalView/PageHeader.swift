//
//  PageHeader.swift
//  Cards
//
//  Created by Paolo on 08/10/17.
//  Copyright © 2017 Apple. All rights reserved.
//

import UIKit

@IBDesignable open class PageHeader: Card {
    
    @IBInspectable public var titleSize: CGFloat = 26
    @IBInspectable public var title: String = "title title title title" {
        didSet{
            titleLbl.text = title
        }
    }
    @IBInspectable public var subtitleSize: CGFloat = 17
    @IBInspectable public var subtitle: String = "subtitle subtitle subtitle subtitle subtitle" {
        didSet{
            subtitleLbl.text = subtitle
        }
    }

    //Private Vars
    var titleLbl = UILabel ()
    var subtitleLbl = UILabel()

    // View Life Cycle
    override public init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    
    override open func initialize() {
        super.initialize()
        
        backgroundImageView.addSubview(titleLbl)
        backgroundImageView.addSubview(subtitleLbl)
        tag = 1000
    }
    
    
    override open func draw(_ rect: CGRect) {
        
        //Draw
        super.draw(rect)
        
        titleLbl.textColor = textColor
        titleLbl.text = title
        titleLbl.font = UIFont.systemFont(ofSize: titleSize, weight: .bold)
        titleLbl.adjustsFontSizeToFitWidth = true
        titleLbl.minimumScaleFactor = 0.1
        titleLbl.lineBreakMode = .byClipping
        titleLbl.numberOfLines = 2
        titleLbl.baselineAdjustment = .none
        
        subtitleLbl.text = subtitle
        subtitleLbl.textColor = textColor
        subtitleLbl.font = UIFont.systemFont(ofSize: subtitleSize, weight: .medium)
        subtitleLbl.shadowColor = UIColor.black
        subtitleLbl.shadowOffset = CGSize.zero
        subtitleLbl.adjustsFontSizeToFitWidth = true
        subtitleLbl.minimumScaleFactor = 0.1
        subtitleLbl.lineBreakMode = .byTruncatingTail
        subtitleLbl.numberOfLines = 0
        subtitleLbl.textAlignment = .left
     
        self.layout()
    }
    
    override open func layout(animating: Bool = true) {
        super.layout(animating: animating)
        
//        let gimme  = LayoutHelper(rect: backgroundImageView.bounds)
//        titleLbl.frame = CGRect(x: insets, y: gimme.Y(8, from: categoryLbl), width: gimme.X(80), height: gimme.Y(17))
//        subtitleLbl.frame = CGRect(x: insets, y: gimme.RevY(0, height: gimme.Y(14)) - insets, width: gimme.X(80), height: gimme.Y(14))
        let margin: CGFloat = 16
        let titleYposition = bounds.height - 78
        let subtitleYposition = bounds.height - 38
        
        titleLbl.frame = CGRect(origin: CGPoint(x: margin, y: titleYposition), size: CGSize(width: bounds.width - (margin*2), height: 20))
        subtitleLbl.frame = CGRect(origin: CGPoint(x: margin, y: subtitleYposition), size: CGSize(width: bounds.width - (margin*2), height: 20))
        titleLbl.sizeToFit()
    }
}
