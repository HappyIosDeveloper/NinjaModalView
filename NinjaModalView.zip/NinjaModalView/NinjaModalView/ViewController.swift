//
//  ViewController.swift
//  NinjaModalView
//
//  Created by Alfredo Uzumaki on 4/18/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmptyCell", for: indexPath)
        if let cellView = cell.viewWithTag(1000) as? PageHeader { 
            let cardContent = storyboard!.instantiateViewController(withIdentifier: "YourDetailViewController") as! YourDetailViewController // add any ViewController here
            cellView.shouldPresent(cardContent, from: self, fullscreen: true)
            cellView.backgroundImage = #imageLiteral(resourceName: "asian")
            cellView.title = "title: \(indexPath.row)"
            cellView.subtitle = "subtitle: \(indexPath.row)"
            cellView.shadowOpacity = 0.3
        } else {
            cell.textLabel?.text = "PageHeader Not Found"
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.height / 3
    }
}
